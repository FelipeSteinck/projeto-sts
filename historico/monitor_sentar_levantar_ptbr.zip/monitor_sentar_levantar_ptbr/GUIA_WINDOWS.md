# Guia de instalação e execução no Windows

## 1. Colocar o projeto no computador

Extraia a pasta em:

```text
C:\Users\Felipe Steinck\Documents\monitor_sentar_levantar_ptbr
```

Abra essa pasta no VS Code e crie um terminal PowerShell.

## 2. Copiar o modelo do MediaPipe

Você já utilizou este modelo no projeto anterior. Copie:

```text
pose_landmarker_lite.task
```

para:

```text
monitor_sentar_levantar_ptbr\models\pose_landmarker_lite.task
```

Se preferir aproveitar o arquivo do projeto anterior, estando na raiz desta
nova pasta, adapte o primeiro caminho e execute:

```powershell
Copy-Item `
  "C:\Users\Felipe Steinck\Documents\projeto_classificacao_poses\models\pose_landmarker_lite.task" `
  ".\models\pose_landmarker_lite.task"
```

Confirme:

```powershell
Test-Path ".\models\pose_landmarker_lite.task"
```

O resultado deve ser `True`.

## 3. Criar um ambiente virtual

```powershell
py -V:3.11 -m venv .venv
```

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -Force
```

```powershell
.\.venv\Scripts\Activate.ps1
```

Confirme que o Python da pasta `.venv` está em uso:

```powershell
python --version
where.exe python
```

## 4. Instalar as bibliotecas

O atalho abaixo instala tudo:

```powershell
.\instalar.ps1
```

Ou faça manualmente:

```powershell
python -m pip install --upgrade pip setuptools wheel
python -m pip install -r requirements.txt
python -m pip check
```

## 5. Executar o autoteste

```powershell
.\testar.ps1
```

Ou:

```powershell
python .\main.py --autoteste
```

O resultado esperado termina em:

```text
AUTOTESTE OK
- cálculo de ângulos: OK
- classificação calibrável: OK
- filtro temporal: OK
- máquina de estados e contagem: OK
- renderização da interface em português: OK
```

## 6. Abrir a aplicação

```powershell
.\executar.ps1
```

Ou:

```powershell
python .\main.py
```

## 7. Posicionar a câmera

- Use a câmera lateralmente ao corpo.
- Deixe ombro, quadril, joelho e tornozelo visíveis.
- Inclua a cadeira e os pés no enquadramento.
- Evite roupas com a mesma cor do fundo.
- Use iluminação frontal ou lateral uniforme.

## 8. Calibrar

1. Sente-se na posição inicial e permaneça imóvel.
2. Pressione `1`.
3. Levante-se completamente e permaneça imóvel.
4. Pressione `2`.
5. Aguarde a mensagem `Calibração concluída e salva`.
6. Volte a sentar para armar o primeiro ciclo.

A calibração fica em `data\calibracao_sts.json` e será carregada nas próximas
execuções.

## 9. Fazer o teste

Execute pelo menos:

- cinco repetições completas;
- duas tentativas interrompidas antes de ficar em pé;
- uma perda de enquadramento proposital;
- um ensaio com iluminação mais fraca.

Compare o número real de repetições com a contagem exibida. Ao encerrar, o CSV
será salvo em `outputs\sessoes`.

## 10. Se a câmera correta não for a de índice zero

Teste:

```powershell
python .\main.py --camera 1
```

Depois `--camera 2`, se necessário.

## 11. Se a tela não couber no monitor

Use o mínimo suportado:

```powershell
python .\main.py --largura-interface 1050 --altura-interface 700
```

## 12. Gerar somente uma prévia da interface

Esse comando não abre a webcam:

```powershell
python .\main.py --demonstrar-interface ".\docs\minha_previa.png"
```
