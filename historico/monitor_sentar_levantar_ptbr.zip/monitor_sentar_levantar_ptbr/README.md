# Monitor de sentar e levantar

Protótipo acadêmico em visão computacional para reconhecer e contar ciclos
completos do movimento:

```text
sentado -> levantando -> em pé -> sentando -> sentado
```

A aplicação utiliza MediaPipe Pose Landmarker para localizar os pontos do
corpo, calcula ângulos de joelho, quadril e tronco e emprega uma máquina de
estados temporal para rejeitar movimentos incompletos.

## O que mudou nesta versão

- interface redesenhada em português, com acentos;
- vídeo e painel lateral organizados em uma única janela;
- fase, progresso, repetições, ângulos e visibilidade exibidos separadamente;
- calibração individual guiada pelas teclas `1` e `2`;
- controles para pausar, reiniciar, espelhar e ocultar o esqueleto;
- CSV em português, separado por ponto e vírgula e compatível com Excel;
- módulos separados para núcleo, interface e integração com a webcam;
- autoteste que não precisa de webcam;
- nenhuma imagem ou vídeo é salvo automaticamente.

## Aviso de escopo

O sistema reconhece fases e conta repetições. Ele não diagnostica condições,
não prescreve exercício e não afirma que uma execução é clinicamente correta.
Os limiares calibrados apenas separam as fases do algoritmo.

## Início rápido no Windows

Consulte [GUIA_WINDOWS.md](GUIA_WINDOWS.md). Depois de preparar o ambiente:

```powershell
python .\main.py --autoteste
python .\main.py
```

## Controles

| Tecla | Função |
|---|---|
| `1` | Registrar a postura sentada |
| `2` | Registrar a postura em pé |
| `P` | Pausar ou retomar a análise |
| `R` | Reiniciar os contadores e o estado |
| `M` | Ativar ou desativar o espelho |
| `L` | Mostrar ou ocultar o esqueleto |
| `Q` ou `Esc` | Encerrar |

## Organização

```text
monitor_sentar_levantar_ptbr/
├── main.py
├── src/
│   ├── aplicacao.py
│   ├── interface.py
│   └── nucleo.py
├── models/
│   └── pose_landmarker_lite.task
├── data/
│   └── calibracao_sts.json            # criado após a calibração
├── outputs/sessoes/                    # CSVs das sessões
├── docs/preview_interface.png
├── requirements.txt
├── instalar.ps1
├── executar.ps1
└── testar.ps1
```

## Relação com o projeto de referência

A arquitetura conceitual foi inspirada em
[Pose-Estimation-for-Fitness-Exercise-Analysis](https://github.com/DanielGuarnizo/Pose-Estimation-for-Fitness-Exercise-Analysis): extração de landmarks,
classificação da fase, contagem e retorno visual. O código desta versão foi
reestruturado para o movimento de sentar e levantar e não usa os modelos
Random Forest do repositório de referência, pois eles foram treinados para
agachamento, levantamento terra e supino com dados próprios dos autores.

Para este protótipo, a fase é classificada por ângulos calibrados e filtragem
temporal. Uma etapa futura pode coletar dados rotulados do movimento e comparar
essa abordagem com Random Forest, SVM ou outro classificador supervisionado.

As referências técnicas principais estão reunidas em
[REFERENCIAS.md](REFERENCIAS.md).
