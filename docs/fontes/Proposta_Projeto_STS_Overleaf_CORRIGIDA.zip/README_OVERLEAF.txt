PROPOSTA DE PROJETO — INSTRUÇÕES PARA O OVERLEAF

1. No Overleaf, escolha: New Project > Upload Project.
2. Envie o arquivo ZIP entregue junto com este projeto.
3. Confirme que main.tex é o arquivo principal.
4. Em Menu > Compiler, selecione pdfLaTeX.
5. Clique em Recompile.

Arquivos do projeto:
- main.tex: texto, capa, tabelas, equações e identidade visual;
- referencias.bib: referências bibliográficas;
- logo.jpg: símbolo fornecido pela equipe;
- CTC_logo.png: identidade visual do Centro Tecnológico.

Os dados da capa estão concentrados no início de main.tex, no bloco
"Dados do trabalho". Assim, título, disciplina, professor, cidade e ano
podem ser alterados sem procurar pelo texto em todo o documento.

O ZIP já inclui todos os arquivos necessários. Não altere os nomes das
imagens sem atualizar também os comandos correspondentes em main.tex.

