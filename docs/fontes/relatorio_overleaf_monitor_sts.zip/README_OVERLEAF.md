# Relatório — projeto Overleaf

Este pacote contém o relatório técnico do monitor visual do exercício de sentar e levantar.

## Abrir no Overleaf

1. Acesse o Overleaf e selecione **New Project > Upload Project**.
2. Envie o arquivo ZIP deste pacote.
3. Confirme `main.tex` como documento principal.
4. Use o compilador **pdfLaTeX**.
5. Clique em **Recompile**. O Overleaf executará as passagens necessárias para sumário, referências e citações.

## Personalização rápida

Os dados da capa ficam no início de `main.tex`, em comandos como `\aluno`, `\disciplina`, `\professorresponsavel` e `\semestre`. A turma está indicada como EEL7815/EEL7825 porque o ambiente Moodle e os planos de ensino reúnem as duas disciplinas; mantenha apenas o código em que o aluno estiver matriculado, caso o professor prefira.

## Inserir as fotos

O relatório compila normalmente com espaços reservados. Para preencher cada campo, envie ao projeto do Overleaf uma imagem com o nome exato abaixo e recompile:

- `foto_sentado.jpg`: postura inicial sentado;
- `foto_transicao.jpg`: fase de subida ou descida;
- `foto_em_pe.jpg`: postura final em pé;
- `resultado_calibracao.png`: painel após a calibração;
- `resultado_repeticao.png`: painel mostrando uma repetição concluída;
- `resultado_evento.png`: perda de pose ou tentativa incompleta;
- `resultado_csv.png`: trecho do CSV ou gráfico produzido a partir da sessão.

Use fotografias no enquadramento lateral, com corpo, pés e cadeira completos. As imagens podem ser JPG ou PNG, mas a extensão deve coincidir com o nome usado em `main.tex`. Se quiser usar outro nome, altere somente o primeiro argumento de `\fotoouespaco`.

## Arquivos

- `main.tex`: texto, capa, equações, tabelas, diagramas e apêndices;
- `referencias.bib`: bibliografia em BibTeX;
- `ufsc_ctc.png`: logotipo usado na capa;
- `execucao_preliminar.png`: evidência visual da linha de base;
- `monitorar_sentar_levantar.py`: código-fonte documentado no relatório.

O texto separa explicitamente os resultados já verificados das etapas ainda pendentes e identifica o sistema como protótipo acadêmico não clínico.
